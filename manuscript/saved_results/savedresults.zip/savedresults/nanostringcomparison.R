#in this file, we run the nanostring results for log2 transformed and log2 transformed+median normalised
# to compare with the original results(the nothing one)
#those new ones are saved with different names

.libPaths("/dskh/nobackup/yunwei")
setwd("/dskh/nobackup/yunwei/Analysis_yw/benchmark/202012summaryresult")

library(dplyr)
library(survival)
library(glmnet)
library(rms)
library(tidyverse)
library(caret)
library(pec)
library(coefplot)
library("survAUC")
library(gridExtra)
library(ggplot2)
library("survival")
library(survminer)
library(randomForestSRC)
library(ggRandomForests)
library(penalized)
library(DMwR)
library(randomForest)
library(riskRegression)
library(pROC)
library(ROCR)
library(cvTools)
library(parallel)
library(pbmcapply)
library(MTLR)
library(profmem)
library(keras)
#install_keras()
library(pseudo)
library(survivalROC)
library(survival)
#library(survcomp)#cran package moved to bioconductor
library(survAUC)
library(CoxBoost)
library(limma)
library(partykit)
library(coin)
library(compound.Cox)
library(GenAlgo)
library(survivalsvm)
library(rmatio)
library(MultiAssayExperiment)
source("original_cox_fun.R")
source("p_cox1_fun.R")
source("p_cox2_fun.R")
source("p_cox3_fun.R")
source("rsf1_fun.R")
source("rsf2_fun.R")
source("bw_cox1_fun.R")
source("bw_cox2_fun.R")
source("bw_cox3_fun.R")
source("mtlr_fun.R")
source("dnnsurv_fun.R")
source("getpseudoconditional.R")
source("cox_boost_fun.R")
source("ga_original_cox_fun.R")
source("ga_mtlr_fun.R")
source("ga_cox_boost_fun.R")
source("mtlr_fun2.R")
source("cox_boost_fun2.R")
source("survivalsvm_fun.R")
source("glmnet_lassocox_fun.R")
source("glmnet_ridge_fun.R")
source("glmnet_en_fun.R")

source("rsf1_fun_nodesizefive.R")
source("rsf2_fun_nodesizefive.R")



###############################################################




###############################################################
load("melanomaAssays.rdata")
class(melanomaAssays)
assays(melanomaAssays)
clinical1=as.data.frame(colData(melanomaAssays))
#clinical1=colData(melanomaAssays)

nano1=as.data.frame(assays(melanomaAssays)[["NanoString"]])
dim(nano1) #204 45
boxplot(nano1)
#check for na
any(is.na(nano1))
boxplot(log2(nano1))
nano2=log2(nano1)
dim(nano2) #204  45
#knn imputation
#i think, this knn impute work by row, so that we need the data as genes*patients
library(bnstruct)
set.seed(2021)
newmatrix1=knn.impute(as.matrix((nano2)),10)
#apply(newmatrix1, 2, summary)
dim(newmatrix1) #204  45
index=which((rowSums(newmatrix1)>0))
newmatrix2=newmatrix1[index,] 
dim(newmatrix2) #194 45

#add surv time and status
newmatrix2=t(newmatrix2)
nano2=as.data.frame(newmatrix2)
dim(nano2) 
any(is.na(nano2))
any(is.infinite(as.matrix(nano2)))
nano2$name=rownames(nano2)
nano2$name=as.numeric(nano2$name)
nano2_1=merge(nano2,clinical1,by.x="name",by.y="Tumour_ID")
colnames(nano2_1)
nano2_2=nano2_1[,c(2:195,199,202)]
colnames(nano2_2)[c(195,196)]=c("status","time")
nano2_2$status=as.vector(ifelse(nano2_2$status=="Dead, melanoma",1,0))
table(nano2_2$status) #19 26
colnames(nano2_2)=gsub("\\-", "_", colnames(nano2_2))
colnames(nano2_2)=gsub("\\(", "_", colnames(nano2_2))
colnames(nano2_2)=gsub("\\)", "_", colnames(nano2_2))
fitform_ogl=as.formula(paste("Surv(time, status)~ ", paste(colnames(nano2_2)[1:194], collapse= "+")))
summary(nano2_2$time)

# nano2_2$os_class=as.vector(ifelse(nano2_2$status==1 & 
#                                     nano2_2$time <365*3, "poor", 
#                                   ifelse(nano2_2$status==0 & 
#                                            nano2_2$time >365*3, "good", "not")))
# table(nano2_2$os_class)
formula1=fitform_ogl
formula2=fitform_ogl
formula3=Surv(time,status)~1
formula4=Surv(time,status)~1
timess=seq(as.numeric(summary(nano2_2$time)[2]),as.numeric(summary(nano2_2$time)[5]),(as.numeric(summary(nano2_2$time)[5])-as.numeric(summary(nano2_2$time)[2]))/14)

#2
# data=nano2_2
# cvK=5
# j=1
# bw_cox1_fun(2,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess)
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox1_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_bw_cox1m.rds")
saveRDS(cox1,"melanomananov2_bw_cox1.rds")
cox1<-readRDS("melanomananov2_bw_cox1.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_bw_cox1t.rds")
#3
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox2_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_bw_cox2m.rds")
saveRDS(cox1,"melanomananov2_bw_cox2.rds")
cox1<-readRDS("melanomananov2_bw_cox2.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_bw_cox2t.rds")
#4
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox3_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_bw_cox3m.rds")
saveRDS(cox1,"melanomananov2_bw_cox3.rds")
cox1<-readRDS("melanomananov2_bw_cox3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_bw_cox3t.rds")
#5
#data<-nano2_2
#cvK=5
#j=1
#r=1
#lambda_1=1
#labmda_2=0
#p_cox1_fun(1,nano2_2,5,form1,formula1,formula2,formula3,formula4,timess,1,0)
start_time <- Sys.time()
form1=as.formula(paste("~ ", paste(colnames(nano2_2)[1:28], collapse= "+")))
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_lassocox_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_p_cox1m.rds")
saveRDS(cox1,"melanomananov2_p_cox1.rds")
cox1<-readRDS("melanomananov2_p_cox1.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_p_cox1t.rds")
#6
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_ridge_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess,mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_p_cox2m.rds")
saveRDS(cox1,"melanomananov2_p_cox2.rds")
cox1<-readRDS("mmelanomananov2_p_cox2.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_p_cox2t.rds")
#7
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_en_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_p_cox3m.rds")
saveRDS(cox1,"melanomananov2_p_cox3.rds")
cox1<-readRDS("melanomananov2_p_cox3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_p_cox3t.rds")
# #8
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, rsf1_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"melanomananov2_rsf1m.rds")
# saveRDS(cox1,"melanomananov2_rsf1.rds")
# cox1<-readRDS("melanomananov2_rsf1.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"melanomananov2_rsf1t.rds")
# #9
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, rsf2_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"melanomananov2_rsf2m.rds")
# saveRDS(cox1,"melanomananov2_rsf2.rds")
# cox1<-readRDS("melanomananov2_rsf2.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"melanomananov2_rsf2t.rds")

#8
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, rsf1_fun_nodesizefive,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_rsf3m.rds")
saveRDS(cox1,"melanomananov2_rsf3.rds")
cox1<-readRDS("melanomananov2_rsf3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_rsf3t.rds")
#9
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, rsf2_fun_nodesizefive,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_rsf4m.rds")
saveRDS(cox1,"melanomananov2_rsf4.rds")
cox1<-readRDS("melanomananov2_rsf4.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_rsf4t.rds")

#10
start_time <- Sys.time()
#mtlr_fun(1,clinical4_new,5,fitform_ogl,formula1,formula2,formula3,formula4,timess)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, mtlr_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_mtlrm.rds")
saveRDS(cox1,"melanomananov2_mtlr.rds")
cox1<-readRDS("melanomananov2_mtlr.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_mtlrt.rds")
#11: 
start_time <- Sys.time()
pickedtime=c(530,600)
#data<-nano2_2
#cvK=5
#j=1
#t<-surv_train
#d<-cen_train
#qt=pickedtime
#getPseudoConditional(surv_train, cen_train, c(30,100))
#getPseudoConditional(surv_train, cen_train, pickedtime)
#dnnsurv_fun(1,nano2_2,5,fitform_ogl,formula1,formula2,formula3,formula4,timess,pickedtime)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, dnnsurv_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess,pickedtime, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_dnnsurvm.rds")
saveRDS(cox1,"melanomananov2_dnnsurv.rds")
cox1<-readRDS("melanomananov2_dnnsurv.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_dnnsurvt.rds")

#12
start_time <- Sys.time()
time1=timess[3]
stepnumber=10
penaltynumber=100
#data=veteran
#cvK=5
#j=1
#cox_boost_fun(1,veteran,5,fitform_ogl,formula1,formula2,formula3,formula4,time1,timess,stepnumber,penaltynumber)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, cox_boost_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,time1,timess,stepnumber,penaltynumber, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov2_coxboostm.rds")
saveRDS(cox1,"melanomananov2_coxboost.rds")
cox1<-readRDS("melanomananov2_coxboost.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov2_coxboostt.rds")


# #4
# nano2_2$time=as.numeric(nano2_2$time)
# #survivalsvm_fun(1,nano2_2,5, fitform_ogl,formula1,formula2,formula3, formula4, timess)
# # Error in quadprog::solve.QP(C, -d, t(H), f, meq = meq) : 
# # constraints are inconsistent, no solution! 
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, survivalsvm_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3, formula4, timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"nano_survivalsvmm.rds")
# saveRDS(cox1,"nano_survivalsvm.rds")
# cox1<-readRDS("nano_survivalsvm.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"nano_survivalsvmt.rds")

###############################################################




###############################################################
load("melanomaAssays.rdata")
class(melanomaAssays)
assays(melanomaAssays)
clinical1=as.data.frame(colData(melanomaAssays))
#clinical1=colData(melanomaAssays)

nano1=as.data.frame(assays(melanomaAssays)[["NanoString"]])
dim(nano1) #204 45
boxplot(nano1)
#check for na
any(is.na(nano1))
boxplot(log2(nano1))
nano2=log2(nano1)
#knn imputation
#i think, this knn impute work by row, so that we need the data as genes*patients
library(bnstruct)
set.seed(2021)
newmatrix1=knn.impute(as.matrix((nano2)),10)
#apply(newmatrix1, 2, summary)
dim(newmatrix1) #204  45
index=which((rowSums(newmatrix1)>0))
newmatrix2=newmatrix1[index,] 
dim(newmatrix2) #194 45
#median normalisation: this should put gene*patients
pmedian <- apply(as.matrix(newmatrix2), 2, median, na.rm = TRUE)
adj <- pmedian - median(pmedian)
nano2_norm <- sweep(as.matrix(newmatrix2), 2, adj, FUN = "-") 
boxplot(nano2_norm)
dim(nano2_norm) #194  45
#melanoma nanostring
#add surv time and status
nano2=t(nano2_norm)
nano2=as.data.frame(nano2)
dim(nano2) 
nano2$name=rownames(nano2)
nano2$name=as.numeric(nano2$name)
nano2_1=merge(nano2,clinical1,by.x="name",by.y="Tumour_ID")
colnames(nano2_1)
nano2_2=nano2_1[,c(2:195,199,202)]
colnames(nano2_2)[c(195,196)]=c("status","time")
nano2_2$status=as.vector(ifelse(nano2_2$status=="Dead, melanoma",1,0))
table(nano2_2$status) #19 26
colnames(nano2_2)=gsub("\\-", "_", colnames(nano2_2))
colnames(nano2_2)=gsub("\\(", "_", colnames(nano2_2))
colnames(nano2_2)=gsub("\\)", "_", colnames(nano2_2))
fitform_ogl=as.formula(paste("Surv(time, status)~ ", paste(colnames(nano2_2)[1:194], collapse= "+")))
summary(nano2_2$time)

# nano2_2$os_class=as.vector(ifelse(nano2_2$status==1 & 
#                                     nano2_2$time <365*3, "poor", 
#                                   ifelse(nano2_2$status==0 & 
#                                            nano2_2$time >365*3, "good", "not")))
# table(nano2_2$os_class)
formula1=fitform_ogl
formula2=fitform_ogl
formula3=Surv(time,status)~1
formula4=Surv(time,status)~1
timess=seq(as.numeric(summary(nano2_2$time)[2]),as.numeric(summary(nano2_2$time)[5]),(as.numeric(summary(nano2_2$time)[5])-as.numeric(summary(nano2_2$time)[2]))/14)

#2
bw_cox1_fun(2,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess)
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox1_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_bw_cox1m.rds")
saveRDS(cox1,"melanomananov3_bw_cox1.rds")
cox1<-readRDS("melanomananov3_bw_cox1.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_bw_cox1t.rds")
#3
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox2_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_bw_cox2m.rds")
saveRDS(cox1,"melanomananov3_bw_cox2.rds")
cox1<-readRDS("melanomananov3_bw_cox2.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_bw_cox2t.rds")
#4
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, bw_cox3_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_bw_cox3m.rds")
saveRDS(cox1,"melanomananov3_bw_cox3.rds")
cox1<-readRDS("melanomananov3_bw_cox3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_bw_cox3t.rds")
#5
#data<-nano2_2
#cvK=5
#j=1
#r=1
#lambda_1=1
#labmda_2=0
#p_cox1_fun(1,nano2_2,5,form1,formula1,formula2,formula3,formula4,timess,1,0)
start_time <- Sys.time()
form1=as.formula(paste("~ ", paste(colnames(nano2_2)[1:28], collapse= "+")))
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_lassocox_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_p_cox1m.rds")
saveRDS(cox1,"melanomananov3_p_cox1.rds")
cox1<-readRDS("melanomananov3_p_cox1.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_p_cox1t.rds")
#6
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_ridge_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess,mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_p_cox2m.rds")
saveRDS(cox1,"melanomananov3_p_cox2.rds")
cox1<-readRDS("mmelanomananov3_p_cox2.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_p_cox2t.rds")
#7
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, glmnet_en_fun,nano2_2,5,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_p_cox3m.rds")
saveRDS(cox1,"melanomananov3_p_cox3.rds")
cox1<-readRDS("melanomananov3_p_cox3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_p_cox3t.rds")
# #8
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, rsf1_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"melanomananov3_rsf1m.rds")
# saveRDS(cox1,"melanomananov3_rsf1.rds")
# cox1<-readRDS("melanomananov3_rsf1.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"melanomananov3_rsf1t.rds")
# #9
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, rsf2_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"melanomananov3_rsf2m.rds")
# saveRDS(cox1,"melanomananov3_rsf2.rds")
# cox1<-readRDS("melanomananov3_rsf2.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"melanomananov3_rsf2t.rds")

#8
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, rsf1_fun_nodesizefive,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_rsf3m.rds")
saveRDS(cox1,"melanomananov3_rsf3.rds")
cox1<-readRDS("melanomananov3_rsf3.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_rsf3t.rds")
#9
start_time <- Sys.time()
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, rsf2_fun_nodesizefive,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_rsf4m.rds")
saveRDS(cox1,"melanomananov3_rsf4.rds")
cox1<-readRDS("melanomananov3_rsf4.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_rsf4t.rds")

#10
start_time <- Sys.time()
#mtlr_fun(1,clinical4_new,5,fitform_ogl,formula1,formula2,formula3,formula4,timess)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, mtlr_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_mtlrm.rds")
saveRDS(cox1,"melanomananov3_mtlr.rds")
cox1<-readRDS("melanomananov3_mtlr.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_mtlrt.rds")
#11: 
start_time <- Sys.time()
pickedtime=c(530,600)
#data<-nano2_2
#cvK=5
#j=1
#t<-surv_train
#d<-cen_train
#qt=pickedtime
#getPseudoConditional(surv_train, cen_train, c(30,100))
#getPseudoConditional(surv_train, cen_train, pickedtime)
#dnnsurv_fun(1,nano2_2,5,fitform_ogl,formula1,formula2,formula3,formula4,timess,pickedtime)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, dnnsurv_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,timess,pickedtime, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_dnnsurvm.rds")
saveRDS(cox1,"melanomananov3_dnnsurv.rds")
cox1<-readRDS("melanomananov3_dnnsurv.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_dnnsurvt.rds")

#12
start_time <- Sys.time()
time1=timess[3]
stepnumber=10
penaltynumber=100
#data=veteran
#cvK=5
#j=1
#cox_boost_fun(1,veteran,5,fitform_ogl,formula1,formula2,formula3,formula4,time1,timess,stepnumber,penaltynumber)
Rprof(tf <- "rprof.log",memory.profiling=TRUE)
cox1 <- pbmcapply::pbmclapply(1:20, cox_boost_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3,formula4,time1,timess,stepnumber,penaltynumber, mc.cores = 15)
Rprof(NULL)
mm<-summaryRprof(tf,memory = "both")
mm
saveRDS(mm,"melanomananov3_coxboostm.rds")
saveRDS(cox1,"melanomananov3_coxboost.rds")
cox1<-readRDS("melanomananov3_coxboost.rds")
head(cox1)
end_time <- Sys.time()
saveRDS(end_time - start_time,"melanomananov3_coxboostt.rds")


# #4
# nano2_2$time=as.numeric(nano2_2$time)
# #survivalsvm_fun(1,nano2_2,5, fitform_ogl,formula1,formula2,formula3, formula4, timess)
# # Error in quadprog::solve.QP(C, -d, t(H), f, meq = meq) : 
# # constraints are inconsistent, no solution! 
# start_time <- Sys.time()
# Rprof(tf <- "rprof.log",memory.profiling=TRUE)
# cox1 <- pbmcapply::pbmclapply(1:20, survivalsvm_fun,nano2_2,5, fitform_ogl,formula1,formula2,formula3, formula4, timess, mc.cores = 15)
# Rprof(NULL)
# mm<-summaryRprof(tf,memory = "both")
# mm
# saveRDS(mm,"nano_survivalsvmm.rds")
# saveRDS(cox1,"nano_survivalsvm.rds")
# cox1<-readRDS("nano_survivalsvm.rds")
# head(cox1)
# end_time <- Sys.time()
# saveRDS(end_time - start_time,"nano_survivalsvmt.rds")
